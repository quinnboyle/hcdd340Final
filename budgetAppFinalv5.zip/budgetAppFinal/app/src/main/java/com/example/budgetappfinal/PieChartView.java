package com.example.budgetappfinal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.HashMap;
import java.util.Map;

public class PieChartView extends View {

    private Paint paint;
    private RectF rectF;
    private Map<String, Float> data;
    private int[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.CYAN};

    public PieChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rectF = new RectF();
        data = new HashMap<>();
    }

    public void setData(Map<String, Float> transactionData) {
        data = transactionData;
        invalidate(); // Redraw the view
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float total = 0f;
        for (float value : data.values()) {
            total += value;
        }

        if (total == 0) return; // No data to draw

        float startAngle = 0f;
        rectF.set(50f, 50f, getWidth() - 50f, getHeight() - 50f);

        int colorIndex = 0;
        for (Map.Entry<String, Float> entry : data.entrySet()) {
            float sweepAngle = (entry.getValue() / total) * 360f;
            paint.setColor(colors[colorIndex % colors.length]);
            canvas.drawArc(rectF, startAngle, sweepAngle, true, paint);
            startAngle += sweepAngle;
            colorIndex++;
        }
    }
}
